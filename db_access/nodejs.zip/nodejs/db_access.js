module.exports = {
    // credentials to the DB are here. HIDDEN and not exposed outside
    // NOTE: YOU SHOULD REPLACE WITH YOUR OWN NATURALLY. These are the ones
    // that you set up 
    config: {
        "host": "seats4udb.c2lgduavgifp.us-east-2.rds.amazonaws.com",
        "user": "seats4uAdmin",
        "password": "seats4u:pass",
        "database": "seats4u"
    }
};